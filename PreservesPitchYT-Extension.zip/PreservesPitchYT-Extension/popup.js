// popup.js — handles toggle interaction and state sync

const toggle    = document.getElementById('toggle');
const toggleRow = document.getElementById('toggleRow');
const statusText = document.getElementById('statusText');
const infoBox   = document.getElementById('infoBox');
const body      = document.body;

const TEXT = {
  on:  { status: 'Bật — Pitch thay đổi theo tốc độ ⏩', info: '<span>Bật:</span> Tăng tốc → giọng cao, giảm tốc → giọng trầm. Hiệu ứng băng cassette cũ 📼' },
  off: { status: 'Tắt — Pitch được giữ nguyên',          info: '<span>Tắt:</span> YouTube giữ nguyên cao độ dù chỉnh tốc độ (mặc định).' },
};

function applyUI(enabled) {
  toggle.checked = enabled;
  if (enabled) {
    body.classList.add('active');
    toggleRow.classList.add('on');
    statusText.textContent = TEXT.on.status;
    infoBox.innerHTML = TEXT.on.info;
  } else {
    body.classList.remove('active');
    toggleRow.classList.remove('on');
    statusText.textContent = TEXT.off.status;
    infoBox.innerHTML = TEXT.off.info;
  }
}

// Load current state from storage
chrome.storage.sync.get(['preservesPitchEnabled'], (result) => {
  applyUI(result.preservesPitchEnabled ?? false);
});

// Handle toggle change
toggle.addEventListener('change', () => {
  const enabled = toggle.checked;
  applyUI(enabled);

  // Persist & broadcast
  chrome.runtime.sendMessage({ type: 'SET_STATE', enabled });

  // Also directly inject into the currently active tab (for immediate effect)
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (tab && tab.url && tab.url.includes('youtube.com')) {
      chrome.tabs.sendMessage(tab.id, { type: 'APPLY_STATE', enabled }).catch(() => {});
    }
  });
});

// Clicking the row label also triggers the checkbox via <label for> — no extra handler needed.
