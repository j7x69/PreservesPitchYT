// background.js — service worker
// Syncs enabled state per-tab and injects logic when navigation completes.

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ preservesPitchEnabled: false });
});

// When popup sends a toggle command, relay to the active YT tab
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SET_STATE') {
    chrome.storage.sync.set({ preservesPitchEnabled: msg.enabled }, () => {
      // Push to all YouTube tabs
      chrome.tabs.query({ url: '*://*.youtube.com/*' }, (tabs) => {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(tab.id, {
            type: 'APPLY_STATE',
            enabled: msg.enabled,
          }).catch(() => {});
        });
      });
    });
    sendResponse({ ok: true });
  }
  return true;
});
