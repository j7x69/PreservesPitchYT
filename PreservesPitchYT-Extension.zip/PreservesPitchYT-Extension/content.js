// content.js — Gọn nhẹ, không cần MutationObserver, bắt chuẩn sự kiện từ YouTube

(function () {
  'use strict';

  let isEffectEnabled = false;
  let currentSpeed = 1.0;

  function applyToVideo(video) {
    if (!video) return;
    // Khi bật hiệu ứng Cassette -> preservesPitch phải là false
    const targetPitchState = !isEffectEnabled;
    
    if (video.preservesPitch !== targetPitchState) {
      video.preservesPitch = targetPitchState;
      video.mozPreservesPitch = targetPitchState;
      video.webkitPreservesPitch = targetPitchState;
    }
  }

  function applyToAllVideos() {
    document.querySelectorAll('video').forEach(applyToVideo);
  }

  // Sử dụng Event Capturing (true) ở cấp document để bắt mọi thẻ video (kể cả mới tạo)
  // Mỗi khi video bắt đầu chạy, chuyển bài, hoặc bị YouTube đổi tốc độ -> ép lại preservesPitch ngay
  ['play', 'loadedmetadata', 'ratechange'].forEach((eventName) => {
    document.addEventListener(
      eventName,
      (e) => {
        if (e.target && e.target.nodeName === 'VIDEO') {
          applyToVideo(e.target);
        }
      },
      true // Bắt buộc dùng capture phase vì các sự kiện media không bubble
    );
  });

  // Bắt sự kiện chuyển trang SPA đặc trưng của YouTube
  document.addEventListener('yt-navigate-finish', () => {
    applyToAllVideos();
  });

  // 1. Lấy trạng thái ban đầu khi vừa mở trang
  chrome.storage.sync.get(['preservesPitchEnabled'], (result) => {
    isEffectEnabled = result.preservesPitchEnabled ?? false;
    applyToAllVideos();
  });

  // 2. Tự động lắng nghe thay đổi từ Popup mà không cần background.js làm trung gian
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'sync' && changes.preservesPitchEnabled) {
      isEffectEnabled = changes.preservesPitchEnabled.newValue;
      applyToAllVideos();
    }
  });
})();