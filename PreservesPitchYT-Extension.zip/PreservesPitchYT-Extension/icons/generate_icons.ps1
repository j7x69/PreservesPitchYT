Add-Type -AssemblyName System.Drawing

function New-Icon {
    param([int]$size, [string]$outPath)

    $bmp = New-Object System.Drawing.Bitmap($size, $size)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit

    # Background: very dark
    $g.Clear([System.Drawing.Color]::FromArgb(255, 13, 13, 13))

    # Red glow — simple solid ellipse with low alpha
    $glowBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(60, 220, 30, 0))
    $glowSize = [int]($size * 0.9)
    $glowOff  = [int](($size - $glowSize) / 2)
    $g.FillEllipse($glowBrush, $glowOff, $glowOff, $glowSize, $glowSize)
    $glowBrush.Dispose()

    $pad  = [int]($size * 0.10)
    $h    = [int]($size * 0.58)
    $top  = [int](($size - $h) / 2)
    $lw   = [float][Math]::Max(1.0, $size * 0.07)

    $penW = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(230, 232, 232, 232), $lw)
    $penW.LineJoin = [System.Drawing.Drawing2D.LineJoin]::Round

    # Cassette body
    $r = [int]($size * 0.10)
    $path = New-Object System.Drawing.Drawing2D.GraphicsPath
    $path.AddArc($pad, $top, $r*2, $r*2, 180, 90)
    $path.AddArc($size - $pad - $r*2, $top, $r*2, $r*2, 270, 90)
    $path.AddArc($size - $pad - $r*2, $top + $h - $r*2, $r*2, $r*2, 0, 90)
    $path.AddArc($pad, $top + $h - $r*2, $r*2, $r*2, 90, 90)
    $path.CloseFigure()
    $g.DrawPath($penW, $path)

    $penThin = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(210, 232, 232, 232), [float][Math]::Max(1.0, $size * 0.05))
    $penThin.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
    $penThin.EndCap   = [System.Drawing.Drawing2D.LineCap]::Round

    # Reels
    $reelR = [int]($size * 0.13)
    $reelY = $top + $h - [int]($size * 0.20)
    $r1x   = $pad + [int]($size * 0.18)
    $r2x   = $size - $pad - [int]($size * 0.18)
    $g.DrawEllipse($penThin, $r1x - $reelR, $reelY - $reelR, $reelR*2, $reelR*2)
    $g.DrawEllipse($penThin, $r2x - $reelR, $reelY - $reelR, $reelR*2, $reelR*2)

    # Tape bridge
    $g.DrawLine($penThin, ($r1x + $reelR), $reelY, ($r2x - $reelR), $reelY)

    # Top slot line
    $slotY = $top + [int]($size * 0.15)
    $g.DrawLine($penThin, $pad + [int]($size*0.07), $slotY, $size - $pad - [int]($size*0.07), $slotY)

    $penThin.Dispose()
    $penW.Dispose()
    $g.Dispose()
    $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    Write-Host "Created $size px icon: $outPath"
}

$base = "C:\Users\j7x6\Desktop\PreservesPitchYT-Extension\icons"
New-Icon -size 16  -outPath "$base\icon16.png"
New-Icon -size 48  -outPath "$base\icon48.png"
New-Icon -size 128 -outPath "$base\icon128.png"
Write-Host "Done."
